import java.util.Enumeration;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.net.InetAddress;

public class IPv4 {
  public static void main(String[] args) {
    // store all the Interfaces on this machine
    Enumeration allNetInterfaces = null;
    // try to get all NetWorkInterfaces
    try {
      allNetInterfaces = NetworkInterface.getNetworkInterfaces();
    } catch (java.net.SocketException e) {
      e.printStackTrace();
    }
    // store the Internet Protocol(IP) address
    InetAddress ip = null;

    // loop through all the NetworkInterfaces on this machine
    while (allNetInterfaces.hasMoreElements()) {
      // obtain one of the Interface
      NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
      // store all the IP addresses that are bound to the Interface
      Enumeration addresses = netInterface.getInetAddresses();

      // loop through all the IP addresses
      while (addresses.hasMoreElements()) {
        // obtain one of the IP address
        ip = (InetAddress) addresses.nextElement();
        // the target IP address is the type of Inet4Address
        if (ip != null && ip instanceof Inet4Address) {
          // 127.0.0.1 is a Loop back IPv4 address that we don't want
          if (ip.getHostAddress().equals("127.0.0.1")) {
            continue;
          }
          // print the target IPv4 address
          System.out.println("IPv4 = " + ip.getHostAddress());
          return;
        }
      }
    }
    // No target IPv4 address found
    System.out.println("No network connection");
  }
}